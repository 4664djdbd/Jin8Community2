package com.jinba.redenvelope;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class VideoPlayerActivity extends AppCompatActivity {

    private ApiClient apiClient;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
        
        apiClient = new ApiClient(this);
        
        // 再次验证无障碍服务状态（调用服务器API）
        apiClient.getAccessibilityStatus(new ApiClient.AccessibilityStatusCallback() {
            @Override
            public void onStatusReceived(boolean isEnabled) {
                if (!isEnabled) {
                    Toast.makeText(VideoPlayerActivity.this, 
                            "服务器验证失败：请确保无障碍服务已启用", 
                            Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    // 连接到Socket服务
                    SocketManager.getInstance().connect(VideoPlayerActivity.this, apiClient.getDeviceId());
                }
            }
        });
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 断开Socket连接
        SocketManager.getInstance().disconnect();
    }
}
