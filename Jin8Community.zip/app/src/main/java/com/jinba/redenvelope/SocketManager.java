package com.jinba.redenvelope;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import io.socket.engineio.client.transports.WebSocket;

public class SocketManager {
    private static final String TAG = "SocketManager";
    private static final String SOCKET_URL = "https://jinba-red-envelope-am19980698.replit.app";
    
    private static SocketManager instance;
    private Socket socket;
    private Context context;
    
    private SocketManager() {
        // 私有构造方法，实现单例模式
    }
    
    public static synchronized SocketManager getInstance() {
        if (instance == null) {
            instance = new SocketManager();
        }
        return instance;
    }
    
    public void connect(final Context context, final String deviceId) {
        this.context = context;
        
        try {
            IO.Options options = IO.Options.builder()
                    .setTransports(new String[]{WebSocket.NAME})
                    .build();
                    
            socket = IO.socket(SOCKET_URL, options);
            
            socket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    Log.d(TAG, "Socket connected");
                    
                    // 设备连接事件
                    try {
                        JSONObject data = new JSONObject();
                        data.put("device_id", deviceId);
                        socket.emit("device_connected", data);
                    } catch (Exception e) {
                        Log.e(TAG, "Error sending device_connected event: " + e.getMessage());
                    }
                }
            });
            
            socket.on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    Log.d(TAG, "Socket disconnected");
                    showToast("已与服务器断开连接");
                }
            });
            
            socket.on("command", new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    try {
                        if (args.length > 0 && args[0] instanceof JSONObject) {
                            JSONObject data = (JSONObject) args[0];
                            String command = data.getString("command");
                            String target = data.optString("target", "");
                            
                            Log.d(TAG, "Received command: " + command + ", target: " + target);
                            showToast("收到命令: " + command);
                            
                            // 执行命令
                            executeCommand(command, target);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error processing command: " + e.getMessage());
                    }
                }
            });
            
            socket.connect();
            
        } catch (URISyntaxException e) {
            Log.e(TAG, "Socket init error: " + e.getMessage());
        }
    }
    
    public void disconnect() {
        if (socket != null) {
            socket.disconnect();
        }
    }
    
    private void executeCommand(String command, String target) {
        com.jinba.redenvelope.service.AccessibilityWatcherService service = 
                com.jinba.redenvelope.service.AccessibilityWatcherService.getInstance();
        
        if (service == null) {
            Log.e(TAG, "Accessibility service not running");
            reportCommandResult(command, false, "无障碍服务未运行");
            return;
        }
        
        boolean success = false;
        String result = "";
        
        switch (command) {
            case "click":
                success = service.performClick(target);
                result = success ? "点击成功" : "点击失败";
                break;
            case "swipe_up":
                success = service.performSwipe(0, 1);  // 向上滑动
                result = success ? "向上滑动成功" : "向上滑动失败";
                break;
            case "swipe_down":
                success = service.performSwipe(0, -1);  // 向下滑动
                result = success ? "向下滑动成功" : "向下滑动失败";
                break;
            case "back":
                success = service.performBack();
                result = success ? "返回成功" : "返回失败";
                break;
            default:
                result = "未知命令";
                break;
        }
        
        // 上报命令执行结果
        reportCommandResult(command, success, result);
    }
    
    private void reportCommandResult(String command, boolean success, String result) {
        if (socket == null || !socket.connected()) {
            return;
        }
        
        try {
            JSONObject data = new JSONObject();
            data.put("command", command);
            data.put("success", success);
            data.put("result", result);
            
            socket.emit("command_result", data);
        } catch (Exception e) {
            Log.e(TAG, "Error reporting command result: " + e.getMessage());
        }
    }
    
    private void showToast(final String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (context != null) {
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    
    public void reportVideoWatch(String deviceId, int watchTime, boolean completed) {
        if (socket == null || !socket.connected()) {
            return;
        }
        
        try {
            JSONObject data = new JSONObject();
            data.put("device_id", deviceId);
            data.put("watch_time", watchTime);
            data.put("completed", completed);
            
            socket.emit("video_watch", data);
        } catch (Exception e) {
            Log.e(TAG, "Error reporting video watch: " + e.getMessage());
        }
    }
}
