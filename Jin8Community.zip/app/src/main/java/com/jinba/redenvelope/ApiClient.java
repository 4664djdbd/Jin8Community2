package com.jinba.redenvelope;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.UUID;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ApiClient {
    private static final String TAG = "ApiClient";
    private static final String BASE_URL = "https://jinba-red-envelope-am19980698.replit.app";  // 服务器URL
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    
    private String deviceId;
    private OkHttpClient client;
    private Context context;
    
    public ApiClient(Context context) {
        this.context = context;
        this.client = new OkHttpClient();
        
        // 生成唯一设备ID或从存储中读取
        this.deviceId = "device_" + UUID.randomUUID().toString().substring(0, 12);
    }
    
    /**
     * 注册设备
     */
    public void registerDevice(final Callback callback) {
        try {
            JSONObject json = new JSONObject();
            json.put("device_id", deviceId);
            json.put("device_name", Build.MANUFACTURER + " " + Build.MODEL);
            json.put("device_model", Build.MODEL);
            
            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(BASE_URL + "/api/register_device")
                    .post(body)
                    .build();
                    
            client.newCall(request).enqueue(callback);
        } catch (JSONException e) {
            Log.e(TAG, "Error creating JSON: " + e.getMessage());
        }
    }
    
    /**
     * 更新无障碍服务状态
     */
    public void updateAccessibilityStatus(final boolean isEnabled) {
        try {
            JSONObject json = new JSONObject();
            json.put("device_id", deviceId);
            json.put("accessibility_enabled", isEnabled);
            
            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(BASE_URL + "/api/update_accessibility_status")
                    .post(body)
                    .build();
                    
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Failed to update status: " + e.getMessage());
                }
                
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    Log.d(TAG, "Status updated: " + isEnabled);
                }
            });
        } catch (JSONException e) {
            Log.e(TAG, "Error creating JSON: " + e.getMessage());
        }
    }
    
    /**
     * 获取设备当前无障碍服务状态
     */
    public void getAccessibilityStatus(final AccessibilityStatusCallback callback) {
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/get_device_accessibility_status/" + deviceId)
                .get()
                .build();
                
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to get status: " + e.getMessage());
                deliverResult(callback, false);
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    deliverResult(callback, false);
                    return;
                }
                
                try {
                    String responseBody = response.body().string();
                    JSONObject json = new JSONObject(responseBody);
                    boolean status = json.getBoolean("accessibility_enabled");
                    deliverResult(callback, status);
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing response: " + e.getMessage());
                    deliverResult(callback, false);
                }
            }
        });
    }
    
    private void deliverResult(final AccessibilityStatusCallback callback, final boolean status) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                callback.onStatusReceived(status);
            }
        });
    }
    
    public String getDeviceId() {
        return deviceId;
    }
    
    public interface AccessibilityStatusCallback {
        void onStatusReceived(boolean isEnabled);
    }
}
