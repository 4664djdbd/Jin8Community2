package com.jinba.redenvelope.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import androidx.annotation.RequiresApi;

import com.jinba.redenvelope.AccessibilityManager;
import com.jinba.redenvelope.ApiClient;

import java.util.List;

public class AccessibilityWatcherService extends AccessibilityService {
    private static final String TAG = "AccessibilityService";
    private static AccessibilityWatcherService instance;
    private ApiClient apiClient;
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        apiClient = new ApiClient(this);
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
    }
    
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 监听无障碍事件
        Log.d(TAG, "Accessibility event: " + event.getEventType());
    }
    
    @Override
    public void onInterrupt() {
        Log.d(TAG, "AccessibilityWatcherService interrupted");
    }
    
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "AccessibilityWatcherService connected");
        
        // 报告无障碍服务已启用
        apiClient.updateAccessibilityStatus(true);
    }
    
    public static AccessibilityWatcherService getInstance() {
        return instance;
    }
    
    /**
     * 执行点击操作
     */
    public boolean performClick(String targetText) {
        if (targetText == null || targetText.isEmpty()) {
            return false;
        }
        
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) {
            return false;
        }
        
        // 尝试通过文本查找节点
        List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByText(targetText);
        rootNode.recycle();
        
        if (nodes.isEmpty()) {
            return false;
        }
        
        // 点击找到的第一个节点
        AccessibilityNodeInfo node = nodes.get(0);
        boolean result = node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        node.recycle();
        
        return result;
    }
    
    /**
     * 执行返回操作
     */
    public boolean performBack() {
        return performGlobalAction(GLOBAL_ACTION_BACK);
    }
    
    /**
     * 执行滑动操作
     * @param directionX X方向 (-1左, 0无, 1右)
     * @param directionY Y方向 (-1上, 0无, 1下)
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean performSwipe(int directionX, int directionY) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return false;
        }
        
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) {
            return false;
        }
        
        Rect displayBounds = new Rect();
        rootNode.getBoundsInScreen(displayBounds);
        rootNode.recycle();
        
        int width = displayBounds.width();
        int height = displayBounds.height();
        
        int startX = width / 2;
        int startY = height / 2;
        int endX = startX + (directionX * (width / 3));
        int endY = startY + (directionY * (height / 3));
        
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(endX, endY);
        
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 500));
        
        return dispatchGesture(builder.build(), null, null);
    }
}
