package com.jinba.redenvelope;

import android.content.Context;
import android.provider.Settings;
import android.text.TextUtils;

import com.jinba.redenvelope.service.AccessibilityWatcherService;

public class AccessibilityManager {

    /**
     * 检查无障碍服务是否启用
     */
    public static boolean isAccessibilityServiceEnabled(Context context) {
        String serviceName = context.getPackageName() + "/" + AccessibilityWatcherService.class.getCanonicalName();
        String enabledServices = Settings.Secure.getString(
                context.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        
        return enabledServices != null && enabledServices.contains(serviceName);
    }
    
    /**
     * 检查并上报无障碍服务状态
     */
    public static void checkAndReportAccessibilityStatus(Context context, ApiClient apiClient) {
        boolean isEnabled = isAccessibilityServiceEnabled(context);
        apiClient.updateAccessibilityStatus(isEnabled);
    }
}
